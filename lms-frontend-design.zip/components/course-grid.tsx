import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Play, Lock, CheckCircle2 } from "lucide-react"

const courses = [
  {
    id: 1,
    title: "Penetration Testing Fundamentals",
    description: "Learn ethical hacking and security assessment techniques",
    progress: 100,
    status: "completed",
    level: "Intermediate",
    duration: "8 hours",
  },
  {
    id: 2,
    title: "Cloud Security Architecture",
    description: "Secure AWS, Azure, and GCP cloud environments",
    progress: 45,
    status: "in-progress",
    level: "Advanced",
    duration: "12 hours",
  },
  {
    id: 3,
    title: "Security Operations Center (SOC)",
    description: "Monitor, detect, and respond to security threats",
    progress: 0,
    status: "locked",
    level: "Advanced",
    duration: "16 hours",
  },
  {
    id: 4,
    title: "Cryptography Essentials",
    description: "Understanding encryption, hashing, and PKI",
    progress: 30,
    status: "in-progress",
    level: "Intermediate",
    duration: "10 hours",
  },
]

export function CourseGrid() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Your Courses</h2>
          <p className="text-muted-foreground">Track your learning progress</p>
        </div>
        <Button variant="outline">View All</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {courses.map((course) => (
          <Card key={course.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-lg">{course.title}</CardTitle>
                  <CardDescription>{course.description}</CardDescription>
                </div>
                {course.status === "completed" && <CheckCircle2 className="h-5 w-5 shrink-0 text-accent" />}
                {course.status === "locked" && <Lock className="h-5 w-5 shrink-0 text-muted-foreground" />}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge variant="outline">{course.level}</Badge>
                <span className="text-sm text-muted-foreground">{course.duration}</span>
              </div>

              {course.status !== "locked" && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                </div>
              )}

              <Button
                className="w-full gap-2"
                variant={course.status === "locked" ? "secondary" : "default"}
                disabled={course.status === "locked"}
              >
                {course.status === "completed" && (
                  <>
                    <CheckCircle2 className="h-4 w-4" />
                    Review Course
                  </>
                )}
                {course.status === "in-progress" && (
                  <>
                    <Play className="h-4 w-4" />
                    Continue Learning
                  </>
                )}
                {course.status === "locked" && (
                  <>
                    <Lock className="h-4 w-4" />
                    Locked
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
