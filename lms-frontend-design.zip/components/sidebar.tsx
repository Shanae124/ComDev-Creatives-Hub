"use client"

import { BookOpen, LayoutDashboard, Settings, GraduationCap, BarChart3, Users, FolderTree, Plus } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { useState } from "react"
import { Separator } from "@/components/ui/separator"

const studentNavigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "My Courses", href: "/courses", icon: BookOpen },
  { name: "Certifications", href: "/certifications", icon: GraduationCap },
  { name: "Progress", href: "/progress", icon: BarChart3 },
]

const adminNavigation = [
  { name: "Course Management", href: "/admin/courses", icon: FolderTree },
  { name: "Create Course", href: "/admin/courses/new", icon: Plus },
  { name: "Users", href: "/admin/users", icon: Users },
  { name: "Analytics", href: "/admin/analytics", icon: BarChart3 },
]

export function Sidebar() {
  const [activeItem, setActiveItem] = useState("Dashboard")

  return (
    <aside className="hidden w-72 border-r border-border bg-card lg:block">
      <div className="flex h-full flex-col">
        <div className="flex h-20 items-center gap-3 border-b border-border px-6">
          <Image src="/logo.png" alt="Protexxa" width={48} height={48} className="shrink-0" />
          <div className="flex flex-col">
            <span className="text-lg font-bold leading-tight bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Protexxa
            </span>
            <span className="text-xs text-muted-foreground font-medium">Learning Platform</span>
          </div>
        </div>

        <nav className="flex-1 space-y-6 p-4 overflow-y-auto">
          <div className="space-y-1">
            <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Student</h3>
            {studentNavigation.map((item) => {
              const Icon = item.icon
              const isActive = activeItem === item.name
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setActiveItem(item.name)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                    isActive
                      ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                  )}
                >
                  <Icon className="h-5 w-5" />
                  {item.name}
                </Link>
              )
            })}
          </div>

          <Separator />

          <div className="space-y-1">
            <h3 className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
              Administration
            </h3>
            {adminNavigation.map((item) => {
              const Icon = item.icon
              const isActive = activeItem === item.name
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setActiveItem(item.name)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                    isActive
                      ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
                  )}
                >
                  <Icon className="h-5 w-5" />
                  {item.name}
                </Link>
              )
            })}
          </div>

          <Separator />

          <div className="space-y-1">
            <Link
              href="/settings"
              onClick={() => setActiveItem("Settings")}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                activeItem === "Settings"
                  ? "bg-gradient-to-r from-primary to-secondary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              )}
            >
              <Settings className="h-5 w-5" />
              Settings
            </Link>
          </div>
        </nav>

        <div className="border-t border-border p-4">
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <span>Powered by</span>
            <span className="font-semibold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Protexxa
            </span>
          </div>
        </div>
      </div>
    </aside>
  )
}
